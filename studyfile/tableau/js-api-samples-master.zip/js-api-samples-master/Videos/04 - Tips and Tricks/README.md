# JSAPIVideos - 04 - Tips and Tricks
Companion code to the Tableau JavaScript API Tips and Tricks Video

##This video teaches you:
- Common 'gotchas' of the JSAPI
- How to use the asynchronous functions
- How to create event listeners